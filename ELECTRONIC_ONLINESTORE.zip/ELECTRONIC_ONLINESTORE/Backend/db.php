<?php

$db= mysqli_connect("localhost", "root", "", "onlinestore");
if(!$db){
    die("Connection unsucceful");
}

?>